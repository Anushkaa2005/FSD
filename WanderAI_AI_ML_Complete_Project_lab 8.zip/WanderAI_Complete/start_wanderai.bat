@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Please run setup_ai.bat once before starting WanderAI.
  pause
  exit /b 1
)
if not exist "node_modules" (
  echo Installing Node.js packages...
  call npm.cmd install
  if errorlevel 1 (
    echo Node.js package installation failed.
    pause
    exit /b 1
  )
)
start "WanderAI Python ML Service" "%~dp0.venv\Scripts\python.exe" "%~dp0ai_service\app.py"
timeout /t 2 /nobreak >nul
start "WanderAI Express API" /D "%~dp0" cmd /k npm.cmd run server
timeout /t 2 /nobreak >nul
start "WanderAI React Frontend" /D "%~dp0" cmd /k npm.cmd run dev
echo WanderAI services are starting in three windows.
