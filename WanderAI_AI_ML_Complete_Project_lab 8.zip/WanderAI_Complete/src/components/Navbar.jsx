import { Link, NavLink, useNavigate } from 'react-router-dom';
import { clearSession } from '../api';
export default function Navbar({user,onLogout}){
 const navigate=useNavigate();
 const logout=()=>{clearSession();onLogout();navigate('/');};
 return <header className="topbar"><Link className="brand" to="/"><span className="brand-mark">✦</span> Wander<span>AI</span></Link><nav className="navlinks"><NavLink to="/">Home</NavLink><NavLink to="/explore">Explore</NavLink>{user&&<NavLink to="/ai-planner">AI Planner</NavLink>}{user&&<><NavLink to="/dashboard">Dashboard</NavLink><NavLink to="/trips">My Trips</NavLink><NavLink to="/favorites">Favourites</NavLink></>}</nav><div className="nav-actions">{user?<><Link className="avatar" to="/profile">{user.name?.[0]?.toUpperCase()||'U'}</Link><button className="btn btn-outline btn-small" onClick={logout}>Log out</button></>:<><Link className="login-link" to="/login">Log in</Link><Link className="btn btn-primary btn-small" to="/register">Get started</Link></>}</div></header>
}
