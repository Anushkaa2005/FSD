const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
export function getToken(){return localStorage.getItem('wanderai_token');}
export function saveSession(data){localStorage.setItem('wanderai_token',data.token);localStorage.setItem('wanderai_user',JSON.stringify(data.user));}
export function clearSession(){localStorage.removeItem('wanderai_token');localStorage.removeItem('wanderai_user');}
export function getUser(){try{return JSON.parse(localStorage.getItem('wanderai_user')||'null');}catch{return null;}}
export async function api(path,options={}){
  const headers={'Content-Type':'application/json',...(options.headers||{})};
  if(getToken())headers.Authorization=`Bearer ${getToken()}`;
  const response=await fetch(`${API_URL}${path}`,{...options,headers,body:options.body?JSON.stringify(options.body):undefined});
  const data=await response.json().catch(()=>({message:'Unexpected server response.'}));
  if(!response.ok)throw new Error(data.message||'Request failed.');
  return data;
}
