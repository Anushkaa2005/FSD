import { useEffect, useMemo, useState } from 'react';
import { api } from '../api';

const interestsList=['nature','adventure','culture','food','wellness'];
const styles=['any','mountains','beach','culture','adventure','nature','city'];
const blank={budget:'15000',days:'4',style:'any',travel_type:'Leisure',interests:['nature','adventure']};
const money=n=>`₹${Number(n||0).toLocaleString('en-IN')}`;

export default function AIPlanner(){
  const [tab,setTab]=useState('recommend');
  const [destinations,setDestinations]=useState([]);
  const [recommendForm,setRecommendForm]=useState(blank);
  const [recommendations,setRecommendations]=useState([]);
  const [budgetForm,setBudgetForm]=useState({destination:'Manali',days:'4',travellers:'2',stay:'standard'});
  const [budgetResult,setBudgetResult]=useState(null);
  const [itineraryForm,setItineraryForm]=useState({destination:'Goa',days:'3',budget:'12000',interests:['nature','food','adventure']});
  const [itinerary,setItinerary]=useState(null);
  const [loading,setLoading]=useState(false);
  const [error,setError]=useState('');
  const [notice,setNotice]=useState('');

  useEffect(()=>{api('/ai/destinations').then(d=>{setDestinations(d.destinations||[]);if(d.destinations?.length){setBudgetForm(f=>({...f,destination:d.destinations.some(x=>x.destination===f.destination)?f.destination:d.destinations[0].destination}));setItineraryForm(f=>({...f,destination:d.destinations.some(x=>x.destination===f.destination)?f.destination:d.destinations[0].destination}));}}).catch(e=>setError(e.message));},[]);
  const toggleInterest=(setter,state,value)=>setter({...state,interests:state.interests.includes(value)?state.interests.filter(x=>x!==value):[...state.interests,value]});
  const submitRecommendations=async e=>{e.preventDefault();setLoading(true);setError('');setRecommendations([]);try{const d=await api('/ai/recommendations',{method:'POST',body:{...recommendForm,budget:Number(recommendForm.budget),days:Number(recommendForm.days)}});setRecommendations(d.recommendations||[]);setNotice(`${d.model} generated ${d.recommendations?.length||0} recommendations.`);}catch(e){setError(e.message);}finally{setLoading(false);}};
  const submitBudget=async e=>{e.preventDefault();setLoading(true);setError('');setBudgetResult(null);try{setBudgetResult(await api('/ai/budget',{method:'POST',body:{...budgetForm,days:Number(budgetForm.days),travellers:Number(budgetForm.travellers)}}));}catch(e){setError(e.message);}finally{setLoading(false);}};
  const submitItinerary=async e=>{e.preventDefault();setLoading(true);setError('');setItinerary(null);try{setItinerary(await api('/ai/itinerary',{method:'POST',body:{...itineraryForm,days:Number(itineraryForm.days),budget:Number(itineraryForm.budget)}}));}catch(e){setError(e.message);}finally{setLoading(false);}};
  const destinationOptions=destinations.length?destinations.map(d=>d.destination):['Manali','Goa','Jaipur'];
  return <main className="page-shell ai-page">
    <div className="ai-hero"><span className="eyebrow purple">YOUR SMART TRAVEL COMPANION</span><h1>WanderAI <em>Intelligence</em></h1><p>Discover destinations, estimate your travel budget and build a day-wise itinerary using machine learning.</p><div className="ai-model-tags"><span>✦ KNN Recommendations</span><span>◈ Random Forest Budget</span><span>⌁ TF-IDF Itinerary</span></div></div>
    <div className="ai-tabs" role="tablist">
      <button className={tab==='recommend'?'active':''} onClick={()=>setTab('recommend')}>✦ Destination match</button>
      <button className={tab==='budget'?'active':''} onClick={()=>setTab('budget')}>₹ Budget prediction</button>
      <button className={tab==='itinerary'?'active':''} onClick={()=>setTab('itinerary')}>☷ Smart itinerary</button>
    </div>
    {error&&<div className="alert error">{error}</div>}{notice&&tab==='recommend'&&<div className="alert success">{notice}</div>}
    {tab==='recommend'&&<section className="ai-panel"><div className="ai-panel-heading"><div><span className="eyebrow purple">MODEL 01 · K-NEAREST NEIGHBORS</span><h2>Find your kind of place</h2><p className="muted">Tell us what matters to you. The model compares your preferences with destination profiles.</p></div><span className="ai-chip">Recommendation</span></div>
      <form className="ai-form" onSubmit={submitRecommendations}>
        <label>Maximum budget (₹)<input type="number" min="500" required value={recommendForm.budget} onChange={e=>setRecommendForm({...recommendForm,budget:e.target.value})}/></label>
        <label>Trip duration (days)<input type="number" min="1" max="30" required value={recommendForm.days} onChange={e=>setRecommendForm({...recommendForm,days:e.target.value})}/></label>
        <label>Destination style<select value={recommendForm.style} onChange={e=>setRecommendForm({...recommendForm,style:e.target.value})}>{styles.map(s=><option key={s} value={s}>{s[0].toUpperCase()+s.slice(1)}</option>)}</select></label>
        <label>Travel type<select value={recommendForm.travel_type} onChange={e=>setRecommendForm({...recommendForm,travel_type:e.target.value})}>{['Leisure','Adventure','Family','Friends','Business','Solo','Couple'].map(x=><option key={x}>{x}</option>)}</select></label>
        <div className="ai-wide"><span className="ai-label">Your interests</span><div className="ai-interest-pills">{interestsList.map(x=><button type="button" key={x} className={recommendForm.interests.includes(x)?'selected':''} onClick={()=>toggleInterest(setRecommendForm,recommendForm,x)}>{x}</button>)}</div></div>
        <button className="btn btn-primary ai-submit" disabled={loading}>{loading?'Finding matches…':'Recommend destinations →'}</button>
      </form>
      {recommendations.length>0&&<div className="ai-results"><div className="panel-heading"><h2>Destinations picked for you</h2><span className="ai-chip">KNN results</span></div><div className="ai-result-grid">{recommendations.map(r=><article className="ai-result-card" key={r.destination}><div className="ai-result-top"><span>{r.style}</span><strong>{r.match_score}% match</strong></div><h3>{r.destination}</h3><p>{r.country}</p><p className="muted">{r.reason}</p><div className="ai-result-bottom"><strong>{money(r.estimated_budget)}</strong><small>estimated base cost</small></div></article>)}</div></div>}
    </section>}
    {tab==='budget'&&<section className="ai-panel"><div className="ai-panel-heading"><div><span className="eyebrow purple">MODEL 02 · RANDOM FOREST REGRESSOR</span><h2>Plan a realistic budget</h2><p className="muted">Estimate a trip cost from destination, duration, group size and stay preference.</p></div><span className="ai-chip">Regression</span></div>
      <form className="ai-form" onSubmit={submitBudget}>
        <label>Destination<select value={budgetForm.destination} onChange={e=>setBudgetForm({...budgetForm,destination:e.target.value})}>{destinationOptions.map(x=><option key={x}>{x}</option>)}</select></label>
        <label>Duration (days)<input type="number" min="1" max="30" value={budgetForm.days} onChange={e=>setBudgetForm({...budgetForm,days:e.target.value})}/></label>
        <label>Number of travellers<input type="number" min="1" max="12" value={budgetForm.travellers} onChange={e=>setBudgetForm({...budgetForm,travellers:e.target.value})}/></label>
        <label>Accommodation<select value={budgetForm.stay} onChange={e=>setBudgetForm({...budgetForm,stay:e.target.value})}><option value="budget">Budget</option><option value="standard">Standard</option><option value="premium">Premium</option></select></label>
        <button className="btn btn-primary ai-submit" disabled={loading}>{loading?'Predicting…':'Predict my budget →'}</button>
      </form>
      {budgetResult&&<div className="ai-budget-result"><span className="eyebrow purple">PREDICTED TRIP COST</span><strong className="ai-big-number">{money(budgetResult.predicted_total)}</strong><p className="muted">{budgetResult.destination} · {budgetResult.days} days · {budgetResult.travellers} traveller(s) · {budgetResult.stay} stay</p><div className="ai-breakdown">{Object.entries(budgetResult.breakdown).map(([k,v])=><div key={k}><span>{k}</span><strong>{money(v)}</strong><div className="ai-meter"><i style={{width:`${Math.min(100,v/Math.max(1,budgetResult.predicted_total)*100)}%`}}/></div></div>)}</div><p className="ai-disclaimer">{budgetResult.note}</p></div>}
    </section>}
    {tab==='itinerary'&&<section className="ai-panel"><div className="ai-panel-heading"><div><span className="eyebrow purple">MODEL 03 · TF-IDF + COSINE SIMILARITY</span><h2>Build your day-by-day plan</h2><p className="muted">The model ranks activities against your interests and organizes the highest matches by day.</p></div><span className="ai-chip">Itinerary</span></div>
      <form className="ai-form" onSubmit={submitItinerary}>
        <label>Destination<select value={itineraryForm.destination} onChange={e=>setItineraryForm({...itineraryForm,destination:e.target.value})}>{destinationOptions.map(x=><option key={x}>{x}</option>)}</select></label>
        <label>Duration (days)<input type="number" min="1" max="14" value={itineraryForm.days} onChange={e=>setItineraryForm({...itineraryForm,days:e.target.value})}/></label>
        <label>Activity budget (₹)<input type="number" min="0" value={itineraryForm.budget} onChange={e=>setItineraryForm({...itineraryForm,budget:e.target.value})}/></label>
        <div className="ai-wide"><span className="ai-label">What do you enjoy?</span><div className="ai-interest-pills">{interestsList.map(x=><button type="button" key={x} className={itineraryForm.interests.includes(x)?'selected':''} onClick={()=>toggleInterest(setItineraryForm,itineraryForm,x)}>{x}</button>)}</div></div>
        <button className="btn btn-primary ai-submit" disabled={loading}>{loading?'Creating itinerary…':'Generate itinerary →'}</button>
      </form>
      {itinerary&&<div className="ai-results"><div className="panel-heading"><h2>Your {itinerary.days}-day {itinerary.destination} itinerary</h2><span className="ai-chip">AI-ranked activities</span></div><div className="ai-day-list">{itinerary.plan.map(day=><article className="ai-day" key={day.day}><div className="ai-day-number">DAY {day.day}</div><div className="ai-day-content"><h3>{day.theme}</h3>{day.activities.map((a,i)=><div className="ai-activity" key={`${a.name}-${i}`}><div><strong>{a.name}</strong><small>{a.category} · {a.duration_hours} hours · {a.relevance}% relevance</small></div><b>{money(a.estimated_cost)}</b></div>)}</div></article>)}</div></div>}
    </section>}
    <p className="ai-footnote">ML models run in a separate local Python service. Estimates are indicative and use a curated demonstration dataset, not live booking prices.</p>
  </main>;
}
