import { useEffect,useState } from 'react';
import { Navigate,Route,Routes,useLocation } from 'react-router-dom';
import Navbar from './components/Navbar';import Footer from './components/Footer';
import Home from './pages/Home';import Auth from './pages/Auth';import Dashboard from './pages/Dashboard';import Explore from './pages/Explore';import Trips from './pages/Trips';import Favorites from './pages/Favorites';import Profile from './pages/Profile';import AIPlanner from './pages/AIPlanner';
import { api,clearSession,getToken,getUser } from './api';
function Protected({user,children}){return user?children:<Navigate to="/login" replace/>;}
export default function App(){const [user,setUser]=useState(getUser());const [checking,setChecking]=useState(!!getToken());const location=useLocation();
 useEffect(()=>{if(!getToken()){setChecking(false);return;}api('/auth/me').then(d=>setUser(d.user)).catch(()=>{clearSession();setUser(null);}).finally(()=>setChecking(false));},[]);
 useEffect(()=>{window.scrollTo(0,0);},[location.pathname]);
 if(checking)return <div className="loading-screen"><div className="loader-mark">✦</div><p>Preparing your next adventure…</p></div>;
 return <><Navbar user={user} onLogout={()=>setUser(null)}/><Routes><Route path="/" element={<Home/>}/><Route path="/login" element={user?<Navigate to="/dashboard"/>:<Auth mode="login" onLogin={setUser}/>}/><Route path="/register" element={user?<Navigate to="/dashboard"/>:<Auth mode="register" onLogin={setUser}/>}/><Route path="/explore" element={<Explore user={user}/>}/><Route path="/ai-planner" element={<Protected user={user}><AIPlanner/></Protected>}/><Route path="/dashboard" element={<Protected user={user}><Dashboard user={user}/></Protected>}/><Route path="/trips" element={<Protected user={user}><Trips/></Protected>}/><Route path="/favorites" element={<Protected user={user}><Favorites/></Protected>}/><Route path="/profile" element={<Protected user={user}><Profile user={user} onUpdate={setUser}/></Protected>}/><Route path="*" element={<Navigate to="/" replace/>}/></Routes><Footer/></>;
}
