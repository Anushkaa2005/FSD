import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
const router = Router();
router.use(requireAuth);
const AI_URL = process.env.AI_SERVICE_URL || 'http://127.0.0.1:8000';
async function forward(path, body, res, next) {
  try {
    const response = await fetch(`${AI_URL}${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body || {}),
      signal: AbortSignal.timeout(20000)
    });
    const data = await response.json();
    return res.status(response.status).json(data);
  } catch (error) {
    if (error.name === 'TimeoutError') return res.status(504).json({ message: 'The AI service took too long to respond. Please try again.' });
    return res.status(503).json({ message: 'AI service is unavailable. Start the Python ML service on port 8000.' });
  }
}
router.post('/recommendations', (req,res,next) => forward('/recommend',req.body,res,next));
router.post('/budget', (req,res,next) => forward('/budget',req.body,res,next));
router.post('/itinerary', (req,res,next) => forward('/itinerary',req.body,res,next));
router.get('/destinations', async (req,res) => {
  try {
    const response=await fetch(`${AI_URL}/destinations`,{signal:AbortSignal.timeout(10000)});
    const data=await response.json();res.status(response.status).json(data);
  } catch { res.status(503).json({message:'AI service is unavailable. Start the Python ML service on port 8000.'}); }
});
export default router;
