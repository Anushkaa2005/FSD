import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { all, get, run } from '../database/db.js';
import { createToken, requireAuth } from '../middleware/auth.js';
const router = Router();

router.post('/register', async (req, res, next) => {
  try {
    const { name, email, password } = req.body;
    if (!name?.trim() || !email?.trim() || !password) return res.status(400).json({ message: 'Name, email and password are required.' });
    if (!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ message: 'Enter a valid email address.' });
    if (password.length < 6) return res.status(400).json({ message: 'Password must contain at least 6 characters.' });
    const exists = await get('SELECT id FROM users WHERE email = ?', [email.toLowerCase().trim()]);
    if (exists) return res.status(409).json({ message: 'An account with this email already exists.' });
    const password_hash = await bcrypt.hash(password, 10);
    const result = await run('INSERT INTO users (name,email,password_hash) VALUES (?,?,?)', [name.trim(), email.toLowerCase().trim(), password_hash]);
    const user = { id: result.id, name: name.trim(), email: email.toLowerCase().trim() };
    res.status(201).json({ message: 'Account created successfully.', token: createToken(user), user });
  } catch (err) { next(err); }
});

router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ message: 'Email and password are required.' });
    const user = await get('SELECT * FROM users WHERE email = ?', [email.toLowerCase().trim()]);
    if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ message: 'Incorrect email or password.' });
    const safeUser = { id: user.id, name: user.name, email: user.email };
    res.json({ message: 'Login successful.', token: createToken(safeUser), user: safeUser });
  } catch (err) { next(err); }
});

router.get('/me', requireAuth, async (req, res, next) => {
  try { const user = await get('SELECT id,name,email,created_at FROM users WHERE id = ?', [req.user.id]); res.json({ user }); }
  catch (err) { next(err); }
});
router.put('/me', requireAuth, async (req, res, next) => {
  try {
    const { name } = req.body;
    if (!name?.trim()) return res.status(400).json({ message: 'Name cannot be empty.' });
    await run('UPDATE users SET name = ? WHERE id = ?', [name.trim(), req.user.id]);
    const user = await get('SELECT id,name,email,created_at FROM users WHERE id = ?', [req.user.id]);
    res.json({ message: 'Profile updated.', user });
  } catch (err) { next(err); }
});
export default router;
