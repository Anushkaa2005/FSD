import { Router } from 'express';
import { all, run } from '../database/db.js';
import { requireAuth } from '../middleware/auth.js';
const router=Router();router.use(requireAuth);
router.get('/',async(req,res,next)=>{try{res.json({favorites:await all('SELECT * FROM favorites WHERE user_id=? ORDER BY id DESC',[req.user.id])});}catch(e){next(e);}});
router.post('/',async(req,res,next)=>{try{const {destination,country,image}=req.body;if(!destination?.trim()||!country?.trim())return res.status(400).json({message:'Destination and country are required.'});await run('INSERT OR IGNORE INTO favorites(user_id,destination,country,image) VALUES(?,?,?,?)',[req.user.id,destination.trim(),country.trim(),image||'']);res.status(201).json({message:'Destination saved to favourites.'});}catch(e){next(e);}});
router.delete('/:id',async(req,res,next)=>{try{const r=await run('DELETE FROM favorites WHERE id=? AND user_id=?',[req.params.id,req.user.id]);if(!r.changes)return res.status(404).json({message:'Favourite not found.'});res.json({message:'Favourite removed.'});}catch(e){next(e);}});
export default router;
