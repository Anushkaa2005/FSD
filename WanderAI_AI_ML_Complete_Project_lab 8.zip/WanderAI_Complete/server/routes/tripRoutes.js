import { Router } from 'express';
import { all, get, run } from '../database/db.js';
import { requireAuth } from '../middleware/auth.js';
const router = Router();
router.use(requireAuth);
const valid = (b) => b.title?.trim() && b.destination?.trim() && b.start_date && b.end_date && Number.isFinite(Number(b.budget)) && Number(b.budget) >= 0 && b.end_date >= b.start_date;
router.get('/', async (req,res,next) => {
  try {
    const { search, status, travel_type } = req.query;
    let sql = 'SELECT * FROM trips WHERE user_id = ?'; const p = [req.user.id];
    if (search) { sql += ' AND (title LIKE ? OR destination LIKE ?)'; p.push(`%${search}%`,`%${search}%`); }
    if (travel_type) { sql += ' AND travel_type = ?'; p.push(travel_type); }
    if (status === 'upcoming') sql += " AND start_date >= date('now')";
    if (status === 'past') sql += " AND end_date < date('now')";
    sql += ' ORDER BY start_date ASC'; res.json({ trips: await all(sql,p) });
  } catch(e){next(e);}
});
router.get('/:id', async(req,res,next)=>{try{const trip=await get('SELECT * FROM trips WHERE id=? AND user_id=?',[req.params.id,req.user.id]); if(!trip)return res.status(404).json({message:'Trip not found.'}); res.json({trip});}catch(e){next(e);}});
router.post('/', async(req,res,next)=>{try{if(!valid(req.body))return res.status(400).json({message:'Please enter a title, destination, valid dates and a non-negative budget.'}); const b=req.body; const r=await run('INSERT INTO trips(user_id,title,destination,start_date,end_date,budget,travel_type,notes) VALUES(?,?,?,?,?,?,?,?)',[req.user.id,b.title.trim(),b.destination.trim(),b.start_date,b.end_date,Number(b.budget),b.travel_type||'Leisure',b.notes||'']); res.status(201).json({message:'Trip created.',trip:await get('SELECT * FROM trips WHERE id=?',[r.id])});}catch(e){next(e);}});
router.put('/:id',async(req,res,next)=>{try{if(!valid(req.body))return res.status(400).json({message:'Please enter valid trip details.'}); const b=req.body; const r=await run('UPDATE trips SET title=?,destination=?,start_date=?,end_date=?,budget=?,travel_type=?,notes=? WHERE id=? AND user_id=?',[b.title.trim(),b.destination.trim(),b.start_date,b.end_date,Number(b.budget),b.travel_type||'Leisure',b.notes||'',req.params.id,req.user.id]); if(!r.changes)return res.status(404).json({message:'Trip not found.'}); res.json({message:'Trip updated.',trip:await get('SELECT * FROM trips WHERE id=?',[req.params.id])});}catch(e){next(e);}});
router.delete('/:id',async(req,res,next)=>{try{const r=await run('DELETE FROM trips WHERE id=? AND user_id=?',[req.params.id,req.user.id]); if(!r.changes)return res.status(404).json({message:'Trip not found.'}); res.json({message:'Trip deleted.'});}catch(e){next(e);}});
export default router;
