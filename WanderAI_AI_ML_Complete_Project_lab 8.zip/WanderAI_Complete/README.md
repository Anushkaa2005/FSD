# WanderAI – Complete Travel Management Platform

A full-stack travel planning website built for Exercise 8 using React, Vite, Node.js, Express and SQLite.

## Included features

- Public landing page and destination discovery page
- User registration and login with bcrypt password hashing
- JWT-protected private pages and APIs
- User dashboard with trip statistics and upcoming plans
- Create, view, search, filter, edit and delete trips (CRUD)
- Save and remove favourite destinations
- Profile name update
- Activities REST API with full CRUD support
- SQLite database with users, trips, activities and favorites tables
- Input validation and user-specific data access
- Responsive design for desktop and mobile

## Folder structure

```text
WanderAI_Complete/
├── src/
│   ├── components/       # Navbar and Footer
│   ├── pages/            # Home, Auth, Dashboard, Explore, Trips, Favorites, Profile, AIPlanner
│   ├── api.js            # Frontend API and session helpers
│   ├── App.jsx           # Routes and protected pages
│   ├── main.jsx          # React entry point
│   └── style.css
├── ai_service/           # Python Flask + scikit-learn ML service
│   ├── app.py
│   ├── requirements.txt
│   └── data/              # Curated destination and activity CSV data
├── server/
│   ├── database/db.js    # SQLite setup and helper functions
│   ├── middleware/auth.js
│   ├── routes/            # Auth, trips, activities, favourites APIs
│   └── server.js
├── index.html
├── package.json
├── vite.config.js
└── .env.example
```

## Requirements

- Node.js 18 or newer
- npm
- Visual Studio Code (recommended)

## Run locally on Windows

1. Extract the ZIP file.
2. Open the `WanderAI_Complete` folder in VS Code.
3. Open Terminal and install packages:

   ```bash
   npm.cmd install
   ```

4. Start the Express backend in Terminal 1:

   ```bash
   npm.cmd run server
   ```

   The API runs at `http://localhost:5000`.

5. Open a second terminal and start React/Vite:

   ```bash
   npm.cmd run dev
   ```

6. Open the local URL printed by Vite, normally `http://localhost:5173`.

Keep both terminals open while using the website. The SQLite database file is created automatically at `server/database/wanderai.db` on first backend start.

## First-time use

1. Open the website.
2. Select **Get started** and create an account with your name, email and password (minimum 6 characters).
3. Log in. You will be taken to your dashboard.
4. Create a trip in **My Trips**.
5. Explore destinations and save favourites.
6. Update your profile from the profile avatar.

Use a test email address for classroom demonstrations. Passwords are stored as bcrypt hashes, not plain text. JWT tokens are stored in browser local storage for this classroom project. For production deployment, use HTTPS, a strong private JWT secret, secure cookie-based sessions and additional security controls.

## API endpoints

All endpoints are prefixed with `http://localhost:5000/api`.

### Authentication

- `POST /auth/register` – create an account
- `POST /auth/login` – log in
- `GET /auth/me` – get the logged-in user's profile (Bearer token required)
- `PUT /auth/me` – update profile name (Bearer token required)

### Trips (Bearer token required)

- `GET /trips` – list current user's trips
- `GET /trips?search=Jaipur` – search title/destination
- `GET /trips?status=upcoming` – upcoming trips
- `GET /trips?status=past` – past trips
- `GET /trips?travel_type=Leisure` – filter by type
- `GET /trips/:id` – get one trip
- `POST /trips` – create trip
- `PUT /trips/:id` – update trip
- `DELETE /trips/:id` – delete trip

### Activities (Bearer token required)

- `GET /activities` – list activities
- `GET /activities?category=Nature` – filter by category
- `GET /activities?search=beach` – search name/location
- `GET /activities/:id` – get one activity
- `POST /activities` – create activity
- `PUT /activities/:id` – update activity
- `DELETE /activities/:id` – delete activity

### Favourites (Bearer token required)

- `GET /favorites` – list favourites
- `POST /favorites` – add a favourite
- `DELETE /favorites/:id` – remove a favourite

For protected endpoints in Thunder Client, add header:

```text
Authorization: Bearer YOUR_LOGIN_TOKEN
Content-Type: application/json
```

Example trip JSON for POST/PUT `/api/trips`:

```json
{
  "title": "Weekend in Jaipur",
  "destination": "Jaipur, India",
  "start_date": "2026-12-12",
  "end_date": "2026-12-15",
  "budget": 12000,
  "travel_type": "Friends",
  "notes": "Visit forts and local markets"
}
```

## Exercise 8 demonstration checklist

- Register a new user and log in.
- Show the dashboard and protected-page redirect when logged out.
- Add a trip and show it in My Trips and Dashboard.
- Edit the trip and show the updated values.
- Delete the trip and show it is removed.
- Search trips and apply Upcoming/Past filters.
- Save a destination to Favourites and remove it.
- Update the profile name.
- Use Thunder Client to demonstrate GET, POST, PUT and DELETE APIs.
- Show the SQLite database file under `server/database/`.

## Notes

- The `activities` database and REST endpoints are implemented for the lab API requirements. The current user interface focuses on trips and destination favourites; activities can be tested directly through Thunder Client.
- Destination photographs are loaded from Unsplash and Google Fonts are loaded online, so those visual assets need an internet connection. The core app and local database run on your computer.
- Do not upload `node_modules`, `.env` or the SQLite database file to a public GitHub repository.


## AI/ML features (WanderAI Intelligence)

The project includes three AI/ML tools on the protected **AI Planner** page:

1. **Personalized destination recommendations** — K-Nearest Neighbors (KNN) compares the user's travel style, interests, budget and duration with curated destination profiles.
2. **Travel budget prediction** — a Random Forest Regressor predicts an indicative trip budget from destination, trip duration, group size and accommodation preference.
3. **Smart itinerary generation** — TF-IDF text vectorization and cosine similarity rank activities against the user's interests and arrange the results into a day-wise plan.

### AI/ML architecture

React AI Planner → existing Express API (`/api/ai/*`, JWT protected) → local Python Flask ML service (`127.0.0.1:8000`) → scikit-learn models.

The Python service reads the curated CSV files in `ai_service/data/` and trains the models when it starts. The budget training examples are generated deterministically from the curated destination cost profiles. **These are demonstration estimates, not live prices or a validated market dataset.** Show this limitation clearly in your project presentation.

### Start the AI/ML service on Windows

Keep the existing Node/React setup and add one Python service:

1. Install Python 3.10 or newer.
2. Open a third VS Code terminal in the project root (`WanderAI_Complete`).
3. Create a virtual environment:

   ```powershell
   py -m venv .venv
   ```

4. Activate it:

   ```powershell
   .\.venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, use Command Prompt or run:

   ```powershell
   .\.venv\Scripts\python.exe -m pip install -r ai_service\requirements.txt
   ```

5. Install Python packages:

   ```powershell
   python -m pip install -r ai_service\requirements.txt
   ```

6. Start the ML service:

   ```powershell
   python ai_service\app.py
   ```

   It should report that it is ready on `http://127.0.0.1:8000`.

7. Keep this terminal running. In the other terminals, start the existing backend and frontend as before:

   **Terminal 1 — Express + SQLite**
   ```powershell
   npm.cmd run server
   ```

   **Terminal 2 — React**
   ```powershell
   npm.cmd run dev
   ```

8. Log in to WanderAI and select **AI Planner** in the navigation bar.

### Verify the ML service

Open `http://127.0.0.1:8000/health`. It should return model names and dataset counts.

The Express endpoints are protected by the same login token as the rest of the app:

- `POST /api/ai/recommendations`
- `POST /api/ai/budget`
- `POST /api/ai/itinerary`
- `GET /api/ai/destinations`

If the AI Planner says the service is unavailable, check that the Python terminal is still running on port 8000. The rest of the website (login, trips, favourites and profile) continues to use the original backend and database.
