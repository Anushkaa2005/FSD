from flask import Flask, request, jsonify
from flask_cors import CORS
from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.neighbors import NearestNeighbors
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import random

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
destinations = pd.read_csv(DATA / "destinations.csv")
activities = pd.read_csv(DATA / "activities.csv")

# Model 1: KNN destination recommender trained on curated destination profiles.
feature_columns = ["style", "international", "culture", "adventure", "nature", "comfort", "avg_daily_cost"]
preprocess = ColumnTransformer([
    ("style", OneHotEncoder(handle_unknown="ignore"), ["style"]),
    ("numeric", StandardScaler(), ["international", "culture", "adventure", "nature", "comfort", "avg_daily_cost"])
])
recommend_model = Pipeline([
    ("features", preprocess),
    ("knn", NearestNeighbors(n_neighbors=5, metric="cosine"))
])
recommend_model.fit(destinations[feature_columns])

# Model 2: Random Forest regression trained from seeded trip-cost examples
# generated from the curated destination cost profiles. Predictions are estimates,
# not live market quotes.
rng = np.random.default_rng(42)
training_rows, training_targets = [], []
for _, d in destinations.iterrows():
    for _ in range(100):
        days = int(rng.integers(2, 11))
        travellers = int(rng.integers(1, 6))
        stay = rng.choice(["budget", "standard", "premium"], p=[.35, .5, .15])
        multiplier = {"budget": .72, "standard": 1.0, "premium": 1.65}[stay]
        transport = float(d.avg_daily_cost) * rng.uniform(.18, .48)
        total = (float(d.avg_daily_cost) * days * travellers * multiplier) + transport * travellers
        total *= rng.uniform(.88, 1.14)
        training_rows.append([d.destination, days, travellers, stay, int(d.international)])
        training_targets.append(total)
budget_pre = ColumnTransformer([
    ("destination", OneHotEncoder(handle_unknown="ignore"), ["destination", "stay"]),
    ("numeric", StandardScaler(), ["days", "travellers", "international"])
])
budget_model = Pipeline([
    ("features", budget_pre),
    ("forest", RandomForestRegressor(n_estimators=180, random_state=42, min_samples_leaf=2))
])
budget_model.fit(pd.DataFrame(training_rows, columns=["destination","days","travellers","stay","international"]),
                 np.array(training_targets))

# Model 3: TF-IDF + cosine similarity to rank activities from interests.
activity_text = (activities["name"].astype(str) + " " + activities["category"].astype(str) +
                 " " + activities["destination"].astype(str))
tfidf = TfidfVectorizer(ngram_range=(1,2), stop_words="english")
activity_matrix = tfidf.fit_transform(activity_text)

def clamp_score(v):
    return max(1, min(5, int(v)))

app = Flask(__name__)
CORS(app)

@app.get("/health")
def health():
    return jsonify({"status":"ok","models":["KNN destination recommender","Random Forest budget predictor","TF-IDF itinerary ranker"],
                    "destinations":len(destinations),"activities":len(activities)})

@app.post("/recommend")
def recommend():
    data = request.get_json(silent=True) or {}
    budget = max(500, float(data.get("budget", 15000)))
    style = str(data.get("style", "any")).lower()
    travel_type = str(data.get("travel_type", "Leisure")).lower()
    days = max(1, min(30, int(data.get("days", 4))))
    interests = [str(x).lower() for x in data.get("interests", [])]
    style_map = {"mountains":"mountain","beach":"beach","culture":"culture","adventure":"adventure","nature":"nature","city":"city","any":"nature"}
    wanted_style = style_map.get(style, style)
    interest_set = set(interests)
    interest_scores = {
        "culture":clamp_score(5 if "culture" in interest_set else 3),
        "adventure":clamp_score(5 if "adventure" in interest_set else 3),
        "nature":clamp_score(5 if "nature" in interest_set else 3),
        "comfort":4 if travel_type in ("family","couple") else 3
    }
    avg_daily = budget / max(days,1)
    query = pd.DataFrame([{
        "style":wanted_style if wanted_style in set(destinations["style"]) else "nature",
        "international":1,
        "culture":interest_scores["culture"],
        "adventure":interest_scores["adventure"],
        "nature":interest_scores["nature"],
        "comfort":interest_scores["comfort"],
        "avg_daily_cost":avg_daily
    }])
    transformed = recommend_model.named_steps["features"].transform(query)
    distances, indices = recommend_model.named_steps["knn"].kneighbors(transformed, n_neighbors=len(destinations))
    ranked = []
    for idx, dist in zip(indices[0], distances[0]):
        row = destinations.iloc[int(idx)]
        estimated = float(row.avg_daily_cost) * days
        if estimated <= budget * 1.3:
            ranked.append({
                "destination":row.destination,"country":row.country,"style":row["style"],
                "match_score":round((1-float(dist))*100,1),
                "estimated_budget":round(estimated),
                "reason":f"{row.activity_summary}. Estimated base cost for {days} days."
            })
    return jsonify({"recommendations":ranked[:6],"model":"K-Nearest Neighbors (cosine distance)",
                    "note":"Recommendations use the supplied preferences and curated destination profiles. Budget figures are indicative estimates."})

@app.post("/budget")
def budget():
    data = request.get_json(silent=True) or {}
    destination = str(data.get("destination","")).strip()
    days = max(1,min(30,int(data.get("days",3))))
    travellers = max(1,min(12,int(data.get("travellers",1))))
    stay = str(data.get("stay","standard")).lower()
    if destination not in set(destinations.destination):
        return jsonify({"message":"Choose a destination from the available destination list."}),400
    if stay not in ("budget","standard","premium"):
        return jsonify({"message":"Stay type must be budget, standard or premium."}),400
    row = destinations[destinations.destination==destination].iloc[0]
    X=pd.DataFrame([{"destination":destination,"days":days,"travellers":travellers,"stay":stay,
                     "international":int(row.international)}])
    total=float(budget_model.predict(X)[0])
    # transparent indicative component split
    transport=total*0.22
    stay_cost=total*({"budget":.18,"standard":.28,"premium":.42}[stay])
    food=total*.20
    activities_cost=max(0,total-transport-stay_cost-food)
    return jsonify({"destination":destination,"days":days,"travellers":travellers,"stay":stay,
        "predicted_total":round(total),"per_person":round(total/travellers),
        "breakdown":{"transport":round(transport),"accommodation":round(stay_cost),"food":round(food),"activities":round(activities_cost)},
        "model":"Random Forest Regressor","note":"Indicative ML estimate trained on curated destination cost profiles and generated trip scenarios; not a live quote."})

@app.post("/itinerary")
def itinerary():
    data=request.get_json(silent=True) or {}
    destination=str(data.get("destination","")).strip()
    days=max(1,min(14,int(data.get("days",3))))
    interests=[str(x).lower() for x in data.get("interests",[])]
    budget=max(0,float(data.get("budget",10000)))
    if destination not in set(destinations.destination):
        return jsonify({"message":"Choose a destination from the available destination list."}),400
    query=" ".join(interests+[destination.lower(),"travel activities"])
    q=tfidf.transform([query])
    scores=cosine_similarity(q,activity_matrix).ravel()
    ranked=[]
    for i in scores.argsort()[::-1]:
        a=activities.iloc[int(i)]
        # destination relevance contributes a small boost; interest similarity remains the ML rank.
        boost=.12 if a.destination.lower()==destination.lower() else 0
        ranked.append((float(scores[i])+boost,a))
    selected=[]
    daily_limit=max(2, min(4, int(budget / max(days*800,1))))
    for score,a in ranked:
        if len(selected)>=days*daily_limit: break
        if float(a.estimated_cost) <= max(500,budget/max(days,1)*.75):
            selected.append({"name":a["name"],"category":a.category,"duration_hours":int(a.duration_hours),
                             "estimated_cost":int(a.estimated_cost),"destination":a.destination,
                             "relevance":round(score*100,1)})
    plan=[]
    for day in range(days):
        chunk=selected[day*daily_limit:(day+1)*daily_limit]
        if not chunk: continue
        plan.append({"day":day+1,"theme":chunk[0]["category"].title()+" experiences",
                     "activities":chunk})
    return jsonify({"destination":destination,"days":days,"plan":plan,
        "model":"TF-IDF vectorization + cosine similarity",
        "note":"Activities are ranked by text similarity to your interests, with a small destination-match boost. Costs are illustrative catalogue estimates."})

@app.get("/destinations")
def list_destinations():
    return jsonify({"destinations":destinations[["destination","country","style"]].to_dict(orient="records")})

if __name__ == "__main__":
    print("WanderAI ML service ready: KNN + Random Forest + TF-IDF")
    app.run(host="127.0.0.1", port=8000, debug=False)
