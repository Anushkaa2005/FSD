@echo off
title WanderAI AI Setup
cd /d "%~dp0"
echo Creating Python virtual environment...
py -m venv .venv
if errorlevel 1 (
  echo Could not create the virtual environment. Install Python 3.10+ and try again.
  pause
  exit /b 1
)
echo Installing AI/ML dependencies...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r ai_service\requirements.txt
if errorlevel 1 (
  echo Installation failed. Check your internet connection and Python installation.
  pause
  exit /b 1
)
echo.
echo AI/ML setup completed. Run start_wanderai.bat next.
pause
